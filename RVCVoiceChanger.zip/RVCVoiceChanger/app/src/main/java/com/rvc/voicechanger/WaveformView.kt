package com.rvc.voicechanger

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF6B35")
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }

    private val barCount = 32
    private var amplitudes = FloatArray(barCount) { 0.05f }
    private var targetAmplitudes = FloatArray(barCount) { 0.05f }
    private var isAnimating = false
    private var amplitude = 0
    private var phase = 0f

    private val animator = object : Runnable {
        override fun run() {
            if (!isAnimating) return
            phase += 0.15f
            for (i in 0 until barCount) {
                val wave = (sin((i.toFloat() / barCount * Math.PI * 2) + phase) * 0.3 + 0.3).toFloat()
                val noise = Random.nextFloat() * 0.4f
                targetAmplitudes[i] = (wave + noise) * (amplitude / 100f).coerceAtLeast(0.05f)
                amplitudes[i] = amplitudes[i] * 0.6f + targetAmplitudes[i] * 0.4f
            }
            invalidate()
            postDelayed(this, 50)
        }
    }

    fun startAnimation() {
        isAnimating = true
        post(animator)
    }

    fun stopAnimation() {
        isAnimating = false
        for (i in amplitudes.indices) amplitudes[i] = 0.05f
        invalidate()
    }

    fun setAmplitude(level: Int) {
        amplitude = level
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = h / 2f
        val barW = w / (barCount * 2f)

        for (i in 0 until barCount) {
            val x = (i * 2 + 1) * barW
            val barH = (amplitudes[i] * h).coerceAtLeast(4f)
            paint.alpha = (150 + (amplitudes[i] * 100).toInt()).coerceAtMost(255)
            canvas.drawLine(x, cx - barH / 2, x, cx + barH / 2, paint)
        }
    }
}
