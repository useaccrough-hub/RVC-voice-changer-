package com.rvc.voicechanger

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.rvc.voicechanger.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private val PERMISSION_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        setupUI()
        observeViewModel()
        checkPermissions()
    }

    private fun setupUI() {
        // Start/Stop button
        binding.btnToggle.setOnClickListener {
            if (viewModel.isRunning.value == true) {
                viewModel.stopConversion()
            } else {
                val ip = binding.etServerIp.text.toString().trim()
                if (ip.isEmpty()) {
                    Toast.makeText(this, "Enter server IP first!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                viewModel.startConversion(ip)
            }
        }

        // Pitch slider
        binding.seekPitch.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                val pitch = progress - 12  // Range: -12 to +12
                binding.tvPitchValue.text = if (pitch >= 0) "+$pitch" else "$pitch"
                viewModel.setPitch(pitch)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        binding.seekPitch.progress = 12 // Default = 0

        // Voice model chips
        binding.chipTamilSinger.setOnClickListener { viewModel.selectVoice("tamil_singer", 2) }
        binding.chipDeepBass.setOnClickListener { viewModel.selectVoice("deep_bass", -5) }
        binding.chipAnimeGirl.setOnClickListener { viewModel.selectVoice("anime_girl", 8) }
        binding.chipRobot.setOnClickListener { viewModel.selectVoice("robot", 0) }
        binding.chipOldMan.setOnClickListener { viewModel.selectVoice("old_man", -8) }
        binding.chipChild.setOnClickListener { viewModel.selectVoice("child", 10) }
    }

    private fun observeViewModel() {
        viewModel.isRunning.observe(this) { running ->
            if (running) {
                binding.btnToggle.text = "⏹  STOP"
                binding.btnToggle.setBackgroundColor(getColor(R.color.stop_red))
                binding.tvStatus.text = "🟢  CONVERTING..."
                binding.tvStatus.setTextColor(getColor(R.color.green_active))
                binding.waveformView.startAnimation()
            } else {
                binding.btnToggle.text = "▶  START"
                binding.btnToggle.setBackgroundColor(getColor(R.color.start_green))
                binding.tvStatus.text = "⚪  IDLE"
                binding.tvStatus.setTextColor(getColor(R.color.text_dim))
                binding.waveformView.stopAnimation()
            }
        }

        viewModel.statusMessage.observe(this) { msg ->
            binding.tvLog.append("\n$msg")
            binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
        }

        viewModel.inputLevel.observe(this) { level ->
            binding.progressInput.progress = level
            binding.tvInputLevel.text = "$level%"
            binding.waveformView.setAmplitude(level)
        }

        viewModel.outputLevel.observe(this) { level ->
            binding.progressOutput.progress = level
            binding.tvOutputLevel.text = "$level%"
        }

        viewModel.latency.observe(this) { ms ->
            binding.tvLatency.text = "${ms}ms"
        }

        viewModel.selectedVoiceName.observe(this) { name ->
            binding.tvActiveVoice.text = name
        }

        viewModel.connectionStatus.observe(this) { status ->
            binding.tvConnectionStatus.text = status
            binding.tvConnectionStatus.setTextColor(
                when (status) {
                    "CONNECTED" -> getColor(R.color.green_active)
                    "CONNECTING..." -> getColor(R.color.yellow_warning)
                    else -> getColor(R.color.red_error)
                }
            )
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                PERMISSION_REQUEST_CODE
            )
        } else {
            viewModel.onPermissionGranted()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            viewModel.onPermissionGranted()
            Toast.makeText(this, "Microphone permission granted ✅", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Microphone permission denied ❌", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopConversion()
    }
}
