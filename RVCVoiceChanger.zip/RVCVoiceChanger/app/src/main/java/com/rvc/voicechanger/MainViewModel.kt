package com.rvc.voicechanger

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _isRunning = MutableLiveData(false)
    val isRunning: LiveData<Boolean> = _isRunning

    private val _statusMessage = MutableLiveData("")
    val statusMessage: LiveData<String> = _statusMessage

    private val _inputLevel = MutableLiveData(0)
    val inputLevel: LiveData<Int> = _inputLevel

    private val _outputLevel = MutableLiveData(0)
    val outputLevel: LiveData<Int> = _outputLevel

    private val _latency = MutableLiveData(0)
    val latency: LiveData<Int> = _latency

    private val _selectedVoiceName = MutableLiveData("Tamil Singer")
    val selectedVoiceName: LiveData<String> = _selectedVoiceName

    private val _connectionStatus = MutableLiveData("DISCONNECTED")
    val connectionStatus: LiveData<String> = _connectionStatus

    private var rvcManager: RVCManager? = null
    private var levelSimJob: Job? = null
    private var hasPermission = false
    private var currentPitch = 0

    fun onPermissionGranted() {
        hasPermission = true
        log("✅ Microphone permission granted")
        log("Enter your server IP and press START")
    }

    fun selectVoice(modelName: String, defaultPitch: Int) {
        val displayName = modelName.replace("_", " ")
            .split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        _selectedVoiceName.value = displayName
        currentPitch = defaultPitch
        rvcManager?.setVoiceModel(modelName, defaultPitch)
        log("🎭 Voice model: $displayName (pitch: ${if (defaultPitch >= 0) "+$defaultPitch" else "$defaultPitch"})")
    }

    fun setPitch(pitch: Int) {
        currentPitch = pitch
        rvcManager?.setPitch(pitch)
    }

    fun startConversion(serverIp: String) {
        if (!hasPermission) {
            log("❌ Microphone permission required!")
            return
        }

        _connectionStatus.value = "CONNECTING..."
        log("🔌 Connecting to ws://$serverIp/voice ...")

        rvcManager = RVCManager(
            serverUrl = serverIp,
            onConnected = {
                viewModelScope.launch {
                    _connectionStatus.value = "CONNECTED"
                    _isRunning.value = true
                    log("✅ Connected to RVC server")
                    log("🎙️ Voice: ${_selectedVoiceName.value}")
                    log("🟢 Real-time conversion active")
                    startLevelUpdates()
                }
            },
            onDisconnected = {
                viewModelScope.launch {
                    _connectionStatus.value = "DISCONNECTED"
                    _isRunning.value = false
                    stopLevelUpdates()
                    log("🔌 Disconnected from server")
                }
            },
            onError = { error ->
                viewModelScope.launch {
                    _connectionStatus.value = "ERROR"
                    _isRunning.value = false
                    stopLevelUpdates()
                    log("❌ Error: $error")
                }
            },
            onInputLevel = { level -> _inputLevel.postValue(level) },
            onOutputLevel = { level -> _outputLevel.postValue(level) },
            onLatency = { ms -> _latency.postValue(ms) }
        )

        rvcManager?.start(currentPitch, _selectedVoiceName.value ?: "tamil_singer")
    }

    fun stopConversion() {
        rvcManager?.stop()
        rvcManager = null
        _isRunning.value = false
        _connectionStatus.value = "DISCONNECTED"
        stopLevelUpdates()
        log("⏹ Conversion stopped")
    }

    private fun startLevelUpdates() {
        // Real levels come from RVCManager callbacks
        // This is a fallback simulation if callbacks aren't firing
        levelSimJob = viewModelScope.launch {
            while (_isRunning.value == true) {
                delay(100)
            }
        }
    }

    private fun stopLevelUpdates() {
        levelSimJob?.cancel()
        _inputLevel.value = 0
        _outputLevel.value = 0
        _latency.value = 0
    }

    private fun log(msg: String) {
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        _statusMessage.value = "[$time] $msg"
    }
}
