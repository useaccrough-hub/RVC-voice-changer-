package com.rvc.voicechanger

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import okhttp3.*
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

class RVCManager(
    private val serverUrl: String,
    private val onConnected: () -> Unit,
    private val onDisconnected: () -> Unit,
    private val onError: (String) -> Unit,
    private val onInputLevel: (Int) -> Unit,
    private val onOutputLevel: (Int) -> Unit,
    private val onLatency: (Int) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 16000
        const val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
        const val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
        const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    private val BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING) * 2

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var webSocket: WebSocket? = null
    private var isRunning = false
    private var pitch = 0
    private var voiceModel = "tamil_singer"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(0, java.util.concurrent.TimeUnit.MILLISECONDS) // No timeout for streaming
        .build()

    fun setVoiceModel(model: String, defaultPitch: Int) {
        voiceModel = model
        pitch = defaultPitch
        // Send model change command if connected
        val cmd = """{"cmd":"set_model","model":"$model","pitch":$defaultPitch}"""
        webSocket?.send(cmd)
    }

    fun setPitch(newPitch: Int) {
        pitch = newPitch
        val cmd = """{"cmd":"set_pitch","pitch":$newPitch}"""
        webSocket?.send(cmd)
    }

    fun start(initialPitch: Int, voiceName: String) {
        pitch = initialPitch
        voiceModel = voiceName.lowercase().replace(" ", "_")
        connectWebSocket()
    }

    private fun connectWebSocket() {
        val request = Request.Builder()
            .url("ws://$serverUrl/voice")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                // Send initial config
                val config = """{"cmd":"init","model":"$voiceModel","pitch":$pitch,"sample_rate":$SAMPLE_RATE}"""
                webSocket.send(config)
                onConnected()
                startAudioCapture()
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // Received converted audio bytes from server
                val audioBytes = bytes.toByteArray()
                playAudio(audioBytes)

                // Calculate output level
                val level = calculateLevel(audioBytes)
                onOutputLevel(level)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                // Handle JSON messages (latency ping, status, etc.)
                if (text.contains("latency")) {
                    val ms = text.substringAfter("\"latency\":").substringBefore("}").trim().toIntOrNull() ?: 0
                    onLatency(ms)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                stopAudio()
                onDisconnected()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                stopAudio()
                onError(t.message ?: "Unknown WebSocket error")
            }
        })
    }

    private fun startAudioCapture() {
        if (audioRecord != null) return

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_IN,
            ENCODING,
            BUFFER_SIZE
        )

        audioTrack = AudioTrack(
            AudioManager.STREAM_MUSIC,
            SAMPLE_RATE,
            CHANNEL_OUT,
            ENCODING,
            BUFFER_SIZE,
            AudioTrack.MODE_STREAM
        )

        audioRecord?.startRecording()
        audioTrack?.play()
        isRunning = true

        // Audio capture thread
        Thread {
            val buffer = ShortArray(BUFFER_SIZE / 2)
            while (isRunning) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    // Calculate and report input level
                    val level = calculateLevelFromShorts(buffer, read)
                    onInputLevel(level)

                    // Convert shorts to bytes for WebSocket
                    val byteBuffer = ByteBuffer.allocate(read * 2)
                        .order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) byteBuffer.putShort(buffer[i])

                    // Send to server
                    webSocket?.send(byteBuffer.array().toByteString())
                }
            }
        }.apply {
            name = "AudioCaptureThread"
            isDaemon = true
            start()
        }
    }

    private fun playAudio(audioBytes: ByteArray) {
        audioTrack?.write(audioBytes, 0, audioBytes.size)
    }

    private fun calculateLevel(bytes: ByteArray): Int {
        if (bytes.isEmpty()) return 0
        var sum = 0.0
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val count = bytes.size / 2
        repeat(count) {
            if (buf.hasRemaining() && buf.remaining() >= 2) {
                sum += buf.short.toDouble().let { it * it }
            }
        }
        val rms = sqrt(sum / count)
        return (rms / 32768.0 * 100).toInt().coerceIn(0, 100)
    }

    private fun calculateLevelFromShorts(buffer: ShortArray, count: Int): Int {
        if (count == 0) return 0
        var sum = 0.0
        for (i in 0 until count) sum += buffer[i].toDouble().let { it * it }
        val rms = sqrt(sum / count)
        return (rms / 32768.0 * 100).toInt().coerceIn(0, 100)
    }

    private fun stopAudio() {
        isRunning = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) { /* ignore */ }
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) { /* ignore */ }
    }

    fun stop() {
        isRunning = false
        stopAudio()
        webSocket?.close(1000, "User stopped")
        webSocket = null
    }
}
