"""
RVC Real-Time Voice Changer - Python WebSocket Server
======================================================
Run this on your PC on the SAME WiFi as your Android phone.

Setup:
  pip install fastapi uvicorn websockets numpy soundfile torch

  # Optional but recommended for real RVC:
  git clone https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI
  # Then copy your trained .pth model into this folder

Run:
  python server.py

Then in the Android app, enter your PC's local IP (e.g. 192.168.1.100:8000)
Find your IP with: ipconfig (Windows) or ifconfig (Mac/Linux)
"""

import asyncio
import json
import struct
import time
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uvicorn

app = FastAPI(title="RVC Voice Changer Server")

# ─────────────────────────────────────────────
# RVC Engine (swap this with real RVC if you have it)
# ─────────────────────────────────────────────
class RVCEngine:
    def __init__(self):
        self.model = None
        self.voice_model = "tamil_singer"
        self.pitch = 0
        self.sample_rate = 16000
        self.use_real_rvc = False

        # Try to load real RVC
        try:
            import torch
            # Uncomment and set your model path:
            # self.model = torch.load("your_model.pth", map_location="cpu")
            # self.model.eval()
            # self.use_real_rvc = True
            print("✅ RVC model loaded")
        except Exception as e:
            print(f"⚠ Running in passthrough mode (no RVC model): {e}")

    def set_model(self, model_name: str, pitch: int):
        self.voice_model = model_name
        self.pitch = pitch
        print(f"🎭 Voice model: {model_name}, pitch: {pitch}")

    def set_pitch(self, pitch: int):
        self.pitch = pitch

    def convert(self, audio_bytes: bytes) -> bytes:
        """
        Convert audio using RVC model.
        If no model loaded, applies simple pitch shift as demo.
        """
        # Decode PCM16 bytes to numpy float
        audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0

        if self.use_real_rvc and self.model is not None:
            # ── Real RVC inference ──
            import torch
            with torch.no_grad():
                audio_tensor = torch.from_numpy(audio_np).unsqueeze(0)
                converted = self.model(audio_tensor, self.pitch)
                audio_np = converted.squeeze().numpy()
        else:
            # ── Demo: simple pitch shift via resampling ──
            audio_np = self._demo_pitch_shift(audio_np, self.pitch)

        # Encode back to PCM16
        audio_out = (audio_np * 32767).clip(-32767, 32767).astype(np.int16)
        return audio_out.tobytes()

    def _demo_pitch_shift(self, audio: np.ndarray, semitones: int) -> np.ndarray:
        """Simple pitch shift by resampling (demo only, not high quality)"""
        if semitones == 0:
            return audio
        factor = 2 ** (semitones / 12.0)
        indices = np.round(np.arange(0, len(audio), factor)).astype(int)
        indices = indices[indices < len(audio)]
        shifted = audio[indices]
        # Resize to original length
        result = np.zeros(len(audio), dtype=np.float32)
        copy_len = min(len(shifted), len(result))
        result[:copy_len] = shifted[:copy_len]
        return result


rvc = RVCEngine()

# ─────────────────────────────────────────────
# WebSocket Endpoint
# ─────────────────────────────────────────────
@app.websocket("/voice")
async def voice_websocket(websocket: WebSocket):
    await websocket.accept()
    client = websocket.client
    print(f"📱 Android connected: {client}")

    last_latency_report = time.time()
    chunk_count = 0

    try:
        while True:
            # Receive data from Android
            data = await websocket.receive()

            if "text" in data:
                # Handle JSON commands
                try:
                    msg = json.loads(data["text"])
                    cmd = msg.get("cmd", "")

                    if cmd == "init":
                        rvc.set_model(msg.get("model", "default"), msg.get("pitch", 0))
                        print(f"✅ Initialized: model={msg.get('model')}, pitch={msg.get('pitch')}")

                    elif cmd == "set_model":
                        rvc.set_model(msg.get("model", "default"), msg.get("pitch", 0))

                    elif cmd == "set_pitch":
                        rvc.set_pitch(msg.get("pitch", 0))

                except json.JSONDecodeError:
                    pass

            elif "bytes" in data:
                # Handle audio bytes
                audio_bytes = data["bytes"]
                t_start = time.perf_counter()

                # Convert with RVC
                converted_audio = rvc.convert(audio_bytes)

                t_end = time.perf_counter()
                latency_ms = int((t_end - t_start) * 1000)

                # Send converted audio back
                await websocket.send_bytes(converted_audio)

                chunk_count += 1

                # Send latency update every second
                if time.time() - last_latency_report > 1.0:
                    await websocket.send_text(json.dumps({"latency": latency_ms}))
                    last_latency_report = time.time()

    except WebSocketDisconnect:
        print(f"📵 Android disconnected: {client}")
    except Exception as e:
        print(f"❌ Error: {e}")


@app.get("/")
def root():
    return {
        "status": "RVC Server Running",
        "model": rvc.voice_model,
        "pitch": rvc.pitch,
        "using_real_rvc": rvc.use_real_rvc
    }


if __name__ == "__main__":
    import socket
    # Print local IP so you know what to put in the app
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    print("=" * 50)
    print(f"🚀 RVC Server starting...")
    print(f"📱 Enter this IP in Android app: {local_ip}:8000")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8000)
