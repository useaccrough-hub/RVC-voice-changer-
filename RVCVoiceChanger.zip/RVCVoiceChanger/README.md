# RVC Real-Time Voice Changer — Android App

A real Android app that streams microphone audio to a Python RVC server
and plays back the converted voice in real time.

---

## 📁 Project Structure

```
RVCVoiceChanger/
├── app/src/main/
│   ├── java/com/rvc/voicechanger/
│   │   ├── MainActivity.kt       ← UI + permissions
│   │   ├── MainViewModel.kt      ← State management
│   │   ├── RVCManager.kt         ← Audio capture + WebSocket
│   │   └── WaveformView.kt       ← Custom waveform animation
│   ├── res/
│   │   ├── layout/activity_main.xml
│   │   ├── values/colors.xml
│   │   ├── values/strings.xml
│   │   ├── values/themes.xml
│   │   └── drawable/*.xml
│   └── AndroidManifest.xml
├── build.gradle
├── settings.gradle
└── server.py                     ← Python RVC backend
```

---

## 🚀 Setup Instructions

### Step 1: Open in Android Studio
1. Open Android Studio
2. File → Open → Select this `RVCVoiceChanger` folder
3. Wait for Gradle sync to complete

### Step 2: Add launcher icons (required)
Android Studio will show an error about missing `ic_launcher`.
Right-click `res` → New → Image Asset → create default icons.

### Step 3: Start the Python server on your PC
```bash
pip install fastapi uvicorn websockets numpy soundfile torch
python server.py
```
Note the IP address printed (e.g. `192.168.1.100:8000`)

### Step 4: Connect Android + PC to same WiFi
Both devices must be on the same local network.

### Step 5: Build & run the app
1. Connect your Android phone via USB (enable Developer Mode)
2. Click ▶ Run in Android Studio
3. Enter the server IP shown in Step 3
4. Press START — speak into mic — hear your converted voice!

---

## 🎯 Using Real RVC Models

To use actual RVC voice models instead of the demo pitch-shifter:

1. Clone RVC: `git clone https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI`
2. Train or download a `.pth` voice model
3. In `server.py`, uncomment these lines:
   ```python
   self.model = torch.load("your_model.pth", map_location="cpu")
   self.model.eval()
   self.use_real_rvc = True
   ```
4. Restart the server

---

## ⚡ Performance Tips

| Setting | Value | Effect |
|---------|-------|--------|
| BUFFER_SIZE | Smaller | Less latency |
| Same WiFi | 5GHz | Faster |
| GPU server | CUDA | Faster inference |
| Chunk size | 512 | Lower latency |

---

## 🔧 Troubleshooting

- **Can't connect**: Check both on same WiFi, firewall allows port 8000
- **No audio**: Grant microphone permission in Android Settings
- **High latency**: Use 5GHz WiFi, reduce chunk size
- **Build error**: File → Invalidate Caches → Restart
